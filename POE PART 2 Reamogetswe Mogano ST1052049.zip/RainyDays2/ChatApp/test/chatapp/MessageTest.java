package chatapp;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {
    
    private Message sample;
    
    // runs before each test – creates one message using POE sample data
    @Before
    public void setup() {
        sample = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
    }
    
    // checks that a message of 250 characters or less is allowed
    @Test
    public void lengthIsOk() {
        assertTrue(sample.getText().length() <= 250);
    }
    
    // builds a very long message (260 chars) and verifies the excess count is correct
    @Test
    public void lengthExceeds() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 260; i++) builder.append("z");
        String longText = builder.toString();
        assertTrue(longText.length() > 250);
        int excess = longText.length() - 250;
        assertEquals(10, excess);
    }
    
    // tests that a properly formatted South African phone number passes
    @Test
    public void validDestination() {
        String result = sample.validateDestination();
        assertEquals("Cell phone number successfully captured.", result);
    }
    
    // tests that a badly formatted phone number (no +27, wrong length) is rejected
    @Test
    public void invalidDestination() {
        Message bad = new Message(2, "08575975889", "Hi");
        String result = bad.validateDestination();
        assertTrue(result.contains("incorrectly formatted"));
    }
    
    // verifies the message hash: exact POE case, format pattern, and a loop test
    @Test
    public void hashMatchesRequirement() {
        // exact match required by POE for first test case
        Message poe = new Message(0, "+27718693002", "Hi Tonight", "0012345678");
        assertEquals("00:0:HITONIGHT", poe.getHash());
        
        // any normal message hash must look like "digits:number:UPPERCASELETTERS"
        String h = sample.getHash();
        assertTrue(h.matches("\\d{2}:\\d+:[A-Z]+"));
        
        // loop test over several different messages (required by POE)
        String[] texts = {"Hello world", "Good morning", "See you later"};
        for (int i = 0; i < texts.length; i++) {
            Message m = new Message(i, "+27718693002", texts[i]);
            String hash = m.getHash();
            assertTrue(hash.matches("\\d{2}:" + i + ":[A-Z]+"));
        }
    }
}