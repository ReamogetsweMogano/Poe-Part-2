package chatapp;

import java.util.regex.Pattern;

public class LoginFeature {
    
    private String userDb;
    private String passDb;
    private String firstDb;
    private String lastDb;
    private String phoneDb;
    
    public boolean checkUserName(String s) {
        if (s == null) return false;
        return s.contains("_") && s.length() <= 5;
    }
    
    public boolean checkPasswordComplexity(String s) {
        if (s == null) return false;
        boolean longEnough = s.length() >= 8;
        boolean hasUpper = s.matches(".*[A-Z].*");
        boolean hasDigit = s.matches(".*[0-9].*");
        boolean hasSpecial = s.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\",./<>?~`].*");
        return longEnough && hasUpper && hasDigit && hasSpecial;
    }
    
    // regex learned from https://regex101.com/
    public boolean checkCellPhoneNumber(String s) {
        if (s == null) return false;
        return Pattern.matches("^\\+27[0-9]{9}$", s);
    }
    
    public String registerUser(String u, String p, String f, String l, String ph) {
        StringBuilder sb = new StringBuilder();
        boolean allFine = true;
        
        if (!checkUserName(u)) {
            sb.append("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.\n");
            allFine = false;
        } else {
            sb.append("Username successfully captured.\n");
        }
        
        if (!checkPasswordComplexity(p)) {
            sb.append("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");
            allFine = false;
        } else {
            sb.append("Password successfully captured.\n");
        }
        
        if (!checkCellPhoneNumber(ph)) {
            sb.append("Cell phone number incorrectly formatted or does not contain international code; please correct the number and try again.\n");
            allFine = false;
        } else {
            sb.append("Cell phone number successfully added.\n");
        }
        
        if (allFine) {
            userDb = u;
            passDb = p;
            firstDb = f;
            lastDb = l;
            phoneDb = ph;
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser registered successfully.";
        } else {
            return sb.toString().trim();
        }
    }
    
    public boolean loginUser(String u, String p) {
        if (u == null || p == null) return false;
        return u.equals(userDb) && p.equals(passDb);
    }
    
    public String returnLoginStatus(boolean ok, String f, String l) {
        if (ok)
            return "Welcome " + f + ", " + l + " it is great to see you again.";
        else
            return "Username or password incorrect, please try again.";
    }
}