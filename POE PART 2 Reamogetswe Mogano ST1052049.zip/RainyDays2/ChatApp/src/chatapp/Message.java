package chatapp;

import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;

public class Message {
    
    private String uniqueId;
    private int seq;
    private String destination;
    private String body;
    private String code;
    
    // normal use: random ID
    public Message(int num, String to, String txt) {
        seq = num;
        destination = to;
        body = txt;
        uniqueId = generateId();
        code = makeCode();
    }
    
    // for unit tests: fixed ID
    public Message(int num, String to, String txt, String fixed) {
        seq = num;
        destination = to;
        body = txt;
        uniqueId = fixed;
        code = makeCode();
    }
    
    private String generateId() {
        Random rnd = new Random();
        long val = 1000000000L + (long)(rnd.nextDouble() * 9000000000L);
        return "" + val;
    }
    
    private String cleanWord(String w) {
        return w.replaceAll("[^A-Za-z]", "");
    }
    
    // hash = first two digits of ID : sequence number : first word + last word (all caps, no punctuation)
    public String makeCode() {
        String start = uniqueId.substring(0, 2);
        String[] pieces = body.trim().split("\\s+");
        String firstWord = cleanWord(pieces[0]).toUpperCase();
        String lastWord = cleanWord(pieces[pieces.length - 1]).toUpperCase();
        return start + ":" + seq + ":" + firstWord + lastWord;
    }
    
    public boolean idValid() {
        return uniqueId != null && uniqueId.length() <= 10;
    }
    
    public String validateDestination() {
        if (destination == null || !destination.matches("^\\+27[0-9]{9}$"))
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        return "Cell phone number successfully captured.";
    }
    
    public void saveToJson() {
        try (FileWriter fw = new FileWriter("messages.json", true)) {
            fw.write("{\"id\":\"" + uniqueId + "\", \"hash\":\"" + code + "\", \"to\":\"" + destination + "\", \"msg\":\"" + body + "\"}\n");
        } catch (IOException e) {
            System.out.println("JSON write failed.");
        }
    }
    
    public String getId() { return uniqueId; }
    public int getSeq() { return seq; }
    public String getReceiver() { return destination; }
    public String getText() { return body; }
    public String getHash() { return code; }
}