package chatapp;

import java.util.Scanner;
import java.util.ArrayList;

public class ChatApp {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        LoginFeature helper = new LoginFeature();
        
        // get personal details
        System.out.println("========================================");
        System.out.println("            WELCOME TO CHATAPP");
        System.out.println("========================================\n");
        
        System.out.print("Enter first name: ");
        String first = read.nextLine();
        System.out.print("Enter last name: ");
        String last = read.nextLine();
        System.out.println();
        
        String loginName;
        do {
            System.out.print("Choose username (must have _ and ≤5 letters): ");
            loginName = read.nextLine();
            if (!helper.checkUserName(loginName))
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
        } while (!helper.checkUserName(loginName));
        System.out.println("Username successfully captured.\n");
        
        String loginPass;
        do {
            System.out.print("Choose password (8+ chars, 1 capital, 1 number, 1 special): ");
            loginPass = read.nextLine();
            if (!helper.checkPasswordComplexity(loginPass))
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
        } while (!helper.checkPasswordComplexity(loginPass));
        System.out.println("Password successfully captured.\n");
        
        String mobile;
        do {
            System.out.print("Enter SA mobile (+27 then 9 digits): ");
            mobile = read.nextLine();
            if (!helper.checkCellPhoneNumber(mobile))
                System.out.println("Cell phone number incorrectly formatted or does not contain international code; please correct the number and try again.");
        } while (!helper.checkCellPhoneNumber(mobile));
        System.out.println("Cell phone number successfully added.\n");
        
        String regConfirm = helper.registerUser(loginName, loginPass, first, last, mobile);
        System.out.println(regConfirm);
        
        // login block
        System.out.println("\n========================================");
        System.out.println("              LOGIN SECTION");
        System.out.println("========================================\n");
        boolean authOk = false;
        while (!authOk) {
            System.out.print("Enter username: ");
            String u = read.nextLine();
            System.out.print("Enter password: ");
            String p = read.nextLine();
            authOk = helper.loginUser(u, p);
            if (authOk)
                System.out.println("\n" + helper.returnLoginStatus(true, first, last));
            else
                System.out.println("Username or password incorrect, please try again.\n");
        }
        
        // Part 2 starts
        System.out.println("\n========================================");
        System.out.println("          Welcome to ChatApp");
        System.out.println("========================================");
        
        ArrayList<Message> archive = new ArrayList<>();
        int totalOut = 0;
        boolean stop = false;
        
        while (!stop) {
            System.out.println("\nMenu");
            System.out.println("1. Send messages");
            System.out.println("2. Show recent (coming soon)");
            System.out.println("3. Exit");
            System.out.print("Select: ");
            int choice = read.nextInt();
            read.nextLine();
            
            switch (choice) {
                case 1:
                    System.out.print("How many messages will you send? ");
                    int amount = read.nextInt();
                    read.nextLine();
                    
                    for (int i = 1; i <= amount; i++) {
                        System.out.println("\nMessage " + i);
                        
                        String toNum;
                        do {
                            System.out.print("Recipient (+27 then 9 digits): ");
                            toNum = read.nextLine();
                            if (!helper.checkCellPhoneNumber(toNum))
                                System.out.println("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                        } while (!helper.checkCellPhoneNumber(toNum));
                        
                        String msgText;
                        while (true) {
                            System.out.print("Message text (max 250 chars): ");
                            msgText = read.nextLine();
                            if (msgText.length() <= 250) {
                                System.out.println("Message ready to send.");
                                break;
                            } else {
                                int over = msgText.length() - 250;
                                System.out.println("Message exceeds 250 characters by " + over + "; please reduce the size.");
                            }
                        }
                        
                        Message m = new Message(i, toNum, msgText);
                        
                        System.out.println("\nOptions:");
                        System.out.println("1. Send now");
                        System.out.println("2. Discard");
                        System.out.println("3. Save to JSON");
                        System.out.print("Choose: ");
                        int act = read.nextInt();
                        read.nextLine();
                        
                        switch (act) {
                            case 1:
                                System.out.println("Message successfully sent");
                                totalOut++;
                                archive.add(m);
                                break;
                            case 2:
                                System.out.println("Press 0 to delete the message");
                                break;
                            case 3:
                                System.out.println("Message successfully stored");
                                m.saveToJson();
                                archive.add(m);
                                break;
                            default:
                                System.out.println("Invalid – ignored.");
                        }
                        
                        System.out.println("\nMessage info");
                        System.out.println("ID: " + m.getId());
                        System.out.println("Hash: " + m.getHash());
                        System.out.println("To: " + m.getReceiver());
                        System.out.println("Text: " + m.getText());
                    }
                    
                    System.out.println("\nTotal messages sent: " + totalOut);
                    break;
                    
                case 2:
                    System.out.println("Coming Soon");
                    break;
                    
                case 3:
                    stop = true;
                    System.out.println("Goodbye!");
                    break;
                    
                default:
                    System.out.println("Invalid option.");
            }
        }
        read.close();
    }
}